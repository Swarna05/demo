import snowflake.connector
import psycopg2
import csv
from io import StringIO
import pandas as pd
from dotenv import load_dotenv
import os


load_dotenv()

snowflake_connection = snowflake.connector.connect(
            user=os.getenv('SNOWFLAKE_USER'),
            password=os.getenv('SNOWFLAKE_PASSWORD'),
            account=os.getenv('SNOWFLAKE_ACCOUNT'),
            warehouse=os.getenv('SNOWFLAKE_WAREHOUSE'),
            database=os.getenv('SNOWFLAKE_DATABASE'),
            schema=os.getenv('SNOWFLAKE_SCHEMA'),
            role=os.getenv('SNOWFLAKE_ROLE')
        )




# Check Snowflake connection
try:
    snowflake_connection
    print("Connection to Snowflake successful!")
    
except Exception as e:
    print(f"Error connecting to Snowflake: {str(e)}")

snowflake_cursor = snowflake_connection.cursor()


#     # Connect to PostgreSQL
# pg_connection = psycopg2.connect(
#         dbname=os.getenv('POSTGRES_DB'),
#         user=os.getenv('POSTGRES_USER'),
#         password=os.getenv('POSTGRES_PASSWORD'),
#         host=os.getenv('POSTGRES_HOST'),
#         port=os.getenv('POSTGRES_PORT')  
#     )

# try:  
#     pg_connection 
#     print("Connection to PostgreSQL successful!")
# except psycopg2.Error as e:
#     print("Error connecting to PostgreSQL:", e) 
    
# pg_cursor = pg_connection.cursor()  # Create a cursor object using the connection

# pg_cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE'")
# tables = pg_cursor.fetchall()

# for table in tables:
#     table_name = table[0]
#     # Read data from the table into a pandas DataFrame
#     df = pd.read_sql(f'SELECT * FROM {table_name}', pg_connection)
#     # Export DataFrame to CSV
#     df.to_csv(f'staging/{table_name}.csv', index=False)
#     print(f"Table '{table_name}' exported to CSV successfully.")


# pg_connection.close()

staging_folder = 'staging/'  # Change this to your actual staging folder path

# Get a list of all CSV files in the staging folder
csv_files = [file for file in os.listdir(staging_folder) if file.endswith('.csv')]

for csv_file in csv_files:
    table_name = os.path.splitext(csv_file)[0]  # Use CSV file name as table name
    
    # Read CSV file into DataFrame
    df = pd.read_csv(os.path.join(staging_folder, csv_file))
    
    # Create table in Snowflake
    create_table_query = f"CREATE TABLE {table_name} ("

    for column in df.columns:
        create_table_query += f"{column} VARCHAR,"

    create_table_query = create_table_query[:-1]  # Remove trailing comma
    create_table_query += ")"

   
    # break
    snowflake_cursor.execute(create_table_query)
    print(f"Table '{table_name}' created in Snowflake.")
    
    # Insert data into Snowflake table
    snowflake_cursor.executemany(f"INSERT INTO {table_name} VALUES ({','.join(['%s']*len(df.columns))})", df.values.tolist())
    print(f"Data inserted into table '{table_name}' in Snowflake.")
    
# Commit changes
snowflake_connection.commit()

snowflake_connection.close()